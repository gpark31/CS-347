package IoTHTR;

public class Heat {
	public static boolean living;
	public static double living_speed; // negative number indicates moving away, 
	public static boolean heatDamage;								   //  positive number indicates moving forward
	
	public static void reportDamage() {
		int x = (int) (1000*Math.random());
		if(x == 0)
			heatDamage = true;
		else
			heatDamage = false;
	}
	
	public static void returnInfo() {
		int x = (int) (10*Math.random());
		living_speed = (100*Math.random());
		if(x==0){
			living = true;
			living_speed = living_speed * -1;
		}
		else{
			living = false;
		}
	}
}
