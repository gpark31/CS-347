package IoTHTR;

public class Motion {
	public static boolean object;
	public static boolean MotionDamage;
	
	public static void reportDamage() {
		int x=(int) (1000*Math.random());
		if(x==0)
			MotionDamage = true;
		else
			MotionDamage = false;
	}
	
	public static void returnInfo() {
		int x=(int) (10*Math.random());
		if(x==0)
			 object = true;
		else
			object = false;
	}
}
