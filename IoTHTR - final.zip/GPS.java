package IoTHTR;

public class GPS {
	public static double actualSpeed;
	public static boolean GPSDamage;
	
	public static void reportDamage() {
		int x=(int) (1000*Math.random());
		if(x==0)
			GPSDamage = true;
		else
			GPSDamage = false;
	}
	
	public static void returnInfo() {
		actualSpeed = (220*Math.random());
	}
}
