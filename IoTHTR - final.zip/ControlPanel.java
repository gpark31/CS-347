package IoTHTR;

import java.util.*;
import  java.util.concurrent.TimeUnit;

public class ControlPanel {
	public static String GPSInfo="";
	
	public static void displaySpeed() {
		System.out.println("Current speed: "+ String.format("%.2f",Wheels.currentSpeed) + " km/h");
	}
	public static void displayObjectLocation() {
		if(!Distance.DistanceDamage) {
			System.out.println("Location: [" + Distance.location + "] Distance: " + String.format("%.2f", Distance.distance) + " km");
		}
	}

	public static void displayMoving() {
		if(!Motion.MotionDamage) {
			if(Motion.object && !Heat.living && Wheels.currentSpeed > 5){
				System.out.println("Warning, object detected.");
				displayObjectLocation();
			}
			else if(Heat.living && Wheels.currentSpeed > 0){
				System.out.println("Warning, living object detected.");
				displayObjectLocation();
			}
			else{
				System.out.println("No object detected.");
			}
		}
		else
			System.out.println("Motion sensor malfunction.");
	}
	public static void displaySlipping() {
		if(!Wheels.WheelsDamage) {
			if(Wheels.slippage && Wheels.currentSpeed > 10)
				System.out.println("Warning: slippage detected.");
			else{
				System.out.println("No slippage detected.");
			}
		}
		else
			System.out.println("Wheel sensor malfunction.");
	}
	public static void displayGate(){
		if(!Distance.DistanceDamage) {
			if(Distance.gate && Wheels.currentSpeed > 0){
				System.out.println("Gate malfunction detected.");
			}
			else{
				System.out.println("No gate malfunction detected.");
			}
		}
		else{
			System.out.println("Distance sensor malfunction.");
		}
	}
	public static void displayGPSInfo() {
		if(!GPS.GPSDamage) {
			if(Wheels.currentSpeed > 0){
				System.out.println("Actual Speed is: " + String.format("%.2f", GPS.actualSpeed) + " km/hr");
			}
		}
		else{
			System.out.println("GPS malfunction.");
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		// enter password
		Scanner input = new Scanner(System.in);
		System.out.print("Enter Username: ");
		String username = input.nextLine();
		System.out.print("Enter Password: ");
		String password = input.nextLine();
		
		if(username.compareTo(IoTHTR.user) == 0){
			if(password.compareTo(IoTHTR.password) == 0){
				System.out.println("Loading.....");
				TimeUnit.SECONDS.sleep(1);
				IoTHTR.start();
			}
		} 
		else{
			System.out.println("Incorrect Password or Username.");
			System.exit(1);
		}
		while(IoTHTR.log_in){			
			String log_out = input.nextLine();
			if(log_out.compareTo("exit") == 0){
				input.close();
				IoTHTR.deactivate();
			}
			else{
				//if not testing, input random values
				if(!test.testing){
					GPS.returnInfo();
					Wheels.returnInfo();
					Heat.returnInfo();
					Motion.returnInfo();
					Distance.returnInfo();
				}
				else{
					test.testValues();
				}
				displaySpeed();
				displayMoving();
				displayGate();
				displaySlipping();
				if(Distance.DistanceDamage || GPS.GPSDamage || Heat.heatDamage || Motion.MotionDamage || Wheels.WheelsDamage){
					IoTHTR.enterEmergency();
				}
				if(!Distance.gate && Distance.gateDistance <= 10 && !Distance.DistanceDamage){
					System.out.println("-----------------------------------------------");
					System.out.println("Distance to gate: " + String.format("%.2f", Distance.gateDistance) + " km");
					System.out.println("Conductor, honk the horn.");
					System.out.println("-----------------------------------------------");

				}	
				if(Distance.gate && (Motion.object || Heat.living)) {
					if(Distance.gateDistance > Distance.distance) {
						Distance.gate = false;
					}
					else {
						Motion.object = false;
						Heat.living = false;
					}
				}
				if(!Motion.MotionDamage && !Heat.living && Motion.object && Wheels.currentSpeed > 0 && Distance.location.equals("Front")){
					System.out.println("\nReducing speed and coming to a complete stop.");
					IoTHTR.setSpeed(0, Distance.distance, "object");
				}
				//living object detected at the front
				else if(Heat.living && Wheels.currentSpeed > 0 && Distance.location.equals("Front") && !Heat.heatDamage){
					System.out.println("\nReducing speed and coming to a complete stop.");
					IoTHTR.setSpeed(0, Distance.distance, "living object");
				}
				//living object detected at the back
				else if(Heat.living && Wheels.currentSpeed > 0 && Distance.location.equals("Back") && Heat.living_speed > 0 && !Heat.heatDamage){
					System.out.println("\nIncreasing speed to avoid collision. \nLiving Object Speed: " + String.format("%.2f", Heat.living_speed) + " km/h" );
					double newSpeed = Wheels.currentSpeed + Heat.living_speed;
					if (newSpeed > 220){
						newSpeed = 220;
					}
					IoTHTR.setSpeed(newSpeed, Distance.distance, "living object");
				}
				//living object detected right
				else if(Heat.living && Wheels.currentSpeed > 0 && Distance.location.equals("Right") 
						&& Heat.living_speed > 0 && Distance.distance > 5  && !Heat.heatDamage){
					System.out.println("\nIncreasing speed to avoid collision. \nLiving Object Speed: " + String.format("%.2f", Heat.living_speed) + " km/h" );
					double newSpeed = Wheels.currentSpeed + Heat.living_speed;
					if (newSpeed > 220){
						newSpeed = 220;
					}
					IoTHTR.setSpeed(newSpeed, Distance.distance, "living object");
				}
				//living object detected right & close
				else if(Heat.living && Wheels.currentSpeed > 0 && Distance.location.equals("Right") 
						&& Heat.living_speed > 0 && Distance.distance <= 5  && !Heat.heatDamage){
					System.out.println("\nDecreasing speed to avoid collision or reduce injury. \nLiving Object Speed: " + String.format("%.2f", Heat.living_speed) + " km/h" );
					IoTHTR.setSpeed(0, Distance.distance, "living object");
				}
				//living object detected left
				else if(Heat.living && Wheels.currentSpeed > 0 && Distance.location.equals("Left") 
						&& Heat.living_speed > 0 && Distance.distance > 5  && !Heat.heatDamage){
					System.out.println("\nIncreasing speed to avoid collision. \nLiving Object Speed: " + String.format("%.2f", Heat.living_speed) + " km/h" );
					double newSpeed = Wheels.currentSpeed + Heat.living_speed;
					if (newSpeed > 220){
						newSpeed = 220;
					}
					IoTHTR.setSpeed(newSpeed, Distance.distance, "living object");
				}
				//living object detected left & close
				else if(Heat.living && Wheels.currentSpeed > 0 && Distance.location.equals("Left") 
						&& Heat.living_speed > 0 && Distance.distance <= 5  && !Heat.heatDamage){
					System.out.println("\nDecreasing speed to avoid collision or reduce injury. \nLiving Object Speed: " + String.format("%.2f", Heat.living_speed) + " km/h" );
					
					IoTHTR.setSpeed(0, Distance.distance, "living object");
				}
				//gate malfunction detected
				else if(Distance.gate && !Distance.DistanceDamage && !GPS.GPSDamage){
					System.out.println("\nReducing speed and coming to a complete stop.");
					IoTHTR.setSpeed(0, Distance.gateDistance, "gate");
				}
				else if(Wheels.slippage && !Wheels.WheelsDamage){
					System.out.println("Slippage occurring. Reducing Speed.");
					Wheels.calRPM(Wheels.currentSpeed);
					IoTHTR.slippageSpeed(Wheels.RPM);
				}
			}
			System.out.println("________________________________________________");
		}
	}
}
